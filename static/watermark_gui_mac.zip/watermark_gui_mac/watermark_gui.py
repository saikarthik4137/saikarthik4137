
import os
from tkinter import Tk, filedialog, Label, Button, StringVar, OptionMenu, Entry, Spinbox
from PIL import Image, ImageDraw, ImageFont

def get_fonts(folder="/System/Library/Fonts/Supplemental"):
    fonts = []
    for file in os.listdir(folder):
        if file.endswith(".ttf"):
            fonts.append(os.path.join(folder, file))
    return fonts

def apply_watermark(image_path, watermark_text, font_path, font_size):
    image = Image.open(image_path).convert("RGBA")
    watermark = Image.new("RGBA", image.size)

    draw = ImageDraw.Draw(watermark)
    font = ImageFont.truetype(font_path, font_size)

    bbox = draw.textbbox((0, 0), watermark_text, font=font)
    textwidth = bbox[2] - bbox[0]
    textheight = bbox[3] - bbox[1]

    x = image.width - textwidth - 20
    y = image.height - textheight - 20

    draw.text((x, y), watermark_text, font=font, fill=(255, 255, 255, 128))
    combined = Image.alpha_composite(image, watermark)

    output_path = image_path.replace(".", "_watermarked.")
    combined.convert("RGB").save(output_path)
    return output_path

def select_images():
    files = filedialog.askopenfilenames(title="Select Images", filetypes=[("Images", "*.png *.jpg *.jpeg")])
    if files:
        app.selected_files = files
        status_label.config(text=f"{len(files)} image(s) selected.")

def watermark_images():
    text = watermark_text.get()
    font_path = font_var.get()
    size = int(font_size.get())
    if not app.selected_files:
        status_label.config(text="Please select images first.")
        return
    for file in app.selected_files:
        output = apply_watermark(file, text, font_path, size)
        print(f"Saved: {output}")
    status_label.config(text="Watermarking complete.")

app = Tk()
app.title("Mac Image Watermarker")
app.geometry("500x400")
app.selected_files = []

Label(app, text="Watermark Text:").pack()
watermark_text = Entry(app, width=40)
watermark_text.insert(0, "© Sri Annamalaiyar Jewels")
watermark_text.pack(pady=5)

Label(app, text="Font:").pack()
fonts = get_fonts()
font_var = StringVar(app)
font_var.set(fonts[0])
OptionMenu(app, font_var, *fonts[:50]).pack(pady=5)

Label(app, text="Font Size:").pack()
font_size = Spinbox(app, from_=10, to=100, width=5)
font_size.pack(pady=5)

Button(app, text="Select Images", command=select_images).pack(pady=10)
Button(app, text="Apply Watermark", command=watermark_images).pack(pady=5)

status_label = Label(app, text="")
status_label.pack(pady=20)

app.mainloop()
